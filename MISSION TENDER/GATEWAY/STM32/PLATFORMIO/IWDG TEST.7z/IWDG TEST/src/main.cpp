#include <Arduino.h>
#include <IWatchdog.h>

#define WDT   1UL
#define WDTms WDT*1000UL
#define WDTus WDTms*1000UL

void setup() {
  // put your setup code here, to run once:
IWatchdog.reload();
IWatchdog.clearReset();
IWatchdog.begin(WDTus);
pinMode(PC13, OUTPUT);
digitalWrite(PC13, !HIGH);
delay(100);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(PC13, !LOW);
  // IWatchdog.reload();
}