#include <Arduino.h>
#include <BhanuSTM32EEPROM.h>
#include <BhanuSTM32GSM.h>
#include <SoftwareSerial.h>
#include <BhanuSTM32adc.h>

#define SHOW_SERIAL 1

// configuration
#define vCT_FS    2.545584412//FOR 40A 2000T
#define Lth       0.0   //%
#define Uth       5.0  //%
#define pump_wait 5000//in sec
#define EVENT2_TOUT (60 * 15)

// #define TDS_multiply  //to get ppm//tdsValue=(133.42*compensationVolatge*compensationVolatge*compensationVolatge - 255.86*compensationVolatge*compensationVolatge + 857.39*compensationVolatge)*0.5; //convert voltage value to tds value

// constant
#define ratio_e1  1000

//CONFIG
#define WDT   2UL//IN SEC
#define WDTms WDT*1000UL
#define WDTus WDTms*1000UL

// constant and configuration
#define Lpm_ratio 0.2//7.50//for 30L/min
#define PULSEperL (Lpm_ratio * 60UL)//450.0

// constant tout
#define PULSE_tout  100000UL//in us

//interrupt
#define P_MODE  RISING

// #define RETRY 5

//EEPROM
#define UPLOAD_d  1   //*5sec
#define U_RETRY   3

#define S_HOST    11
#define E_HOST                81
#define S_METHOD  82
#define E_METHOD              132
#define S_CONTENT 133
#define E_CONTENT             173// careful here

#define ADD_SB  (E_CONTENT + 1)

//GSM
#define gsmbaud 115200//19200
#define tout1 100
#define toutHTTPDATA 5000
#define toutSTATUS   20000//8000
#define toutHTTP     6000
#define NOT_INTERNET_COUNT  20
#define DEBUG       0b00110001 //on error quick get error
//#define error       0b00110000
#define nZF1Eo1     0b10010001
#define ZF1Eo1      0b00010001
#define nZF1E0      0b10010000
#define ZF3oEo1     0b00111001
#define ZF3Eo1      0b00110001
#define ZF0Eo1      0b00000001
#define ZF3oE0      0b00111000
#define ZF3E0       0b00110000
#define ZF1E0       0b00010000
#define ZF0E0       0b00000000
#define nZF3oEo1    0b10111001
#define nZF3Eo1     0b10110001
#define nZF3oE0     0b10111000
#define nZF3E0      0b10110000
#define GSMtest     0b00001111
#define GPRStest    0b00001000
#define SIMtest     0b00000010
#define NWtest      0b00000100
#define CCLKtest    0b00010000
#define HouUnix     0b00111100
#define MinUnix     0b00111110
#define SecUnix     0b00111111
#define SAP1APN     0b00000010
#define CSTTAPN     0b00000100
#define BOTHAPN     0b00000110
#define oSAP1APN    0b00000011
#define oCSTTAPN    0b00000101
#define oBOTHAPN    0b00000111
#define GSMHeal     0b00000011//at + sim
#define WiFiHeal    0b00000001//at
#define SwRST       0b00000000
#define SigPct      0b00000000
#define Sigusdb     0b00000001
#define Sigsdb      0b10000001

#define ONE_TIME    0x8000
#define ATV1        0x0001
#define CREG0       0x0002
#define CSDT1       0x0004
#define CSCLK0      0x0008
#define CMGF1       0x0010
#define SLED        0x0020
#define CMGDAall    0x0040
#define CNMI        0x0080//VVI FOR SMS//New SMS Message Indications
#define ATE0        0x0800

#define ONE_TIME_BASIC  0x88BF //(ONE_TIME|ATV1|CREG0|CSDT1|CSCLK0|CMGF1|SLED|CNMI|ATE0)

#define SMEM_TOTAL    0
#define SMEM_SEND     1
#define SMEM_RECEIVE  2

#define _SERIAL Serial1//gsm
#undef Serial
#define Serial SERIAL_//serial
#define DGSM GSM
#define RX PB5//16//PB6//SERIAL RX
#define TX PB12//17//PB7// SERIAL TX

#define RST PA8//PB5//6

//LED
#define PIN_GREEN   PA_7
#define PIN_RED     PA_4
#define PIN_YELLOW  PB_11
#define L_GREEN   PA7
#define L_RED     PA4
#define L_YELLOW  PB11
#define U_LED     L_GREEN
#define S_LED     L_YELLOW
#define D_LED     L_RED

//flow
#define INflow  PA6
#define OUTflow PA5

//ANALOG
#define VREF readVdd()
#define vAI1  PA_0
#define vAI2  PA_3
#define ICTP  PA_1//CT_P

#define TBIN2_8 vAI1
#define TBIN2_6 vAI2
#define TBIN2_4 ICTP
#define TDS_PIN vAI1

// #define E2_U_DURATION 60*30UL//in second

SoftwareSerial SERIAL_(RX, TX);//(RX,TX)

BhanuSTM32GSM GSM(_SERIAL, Serial);//(GSM,Serial)

void GSM_Heal();
void ram();
void Sdebug();
void save_Pulse();
void data_read();
void data_write(uint32_t a, uint32_t b);

int8_t notGPRS = NOT_INTERNET_COUNT;

float Litre_e1 = 0;
uint32_t save_timer = millis()/100;
uint32_t e2_upload_timer = millis()/1000;
uint32_t wait_pump = 0;

//STARTUP LED
void Startup1_calloc()
{
  uint8_t *pin = (uint8_t*)calloc(3, sizeof(uint8_t));
  uint8_t j = 2;
  *(pin + 0) = L_RED;
  *(pin + 1) = L_GREEN;
  *(pin + 2) = L_YELLOW;
  // *(pin + 3) = APP;
  while (j != 0) {
    digitalWrite(*(pin + 0), HIGH);
    delay(50);
    for (uint8_t i = 1; i < 5; i++) {
      digitalWrite(*(pin + i), HIGH);
      delay(30);
      digitalWrite(*(pin + (i + 1)), HIGH);
      delay(20);
      if (j % 2 != 0) {
        digitalWrite(*(pin + (i - 1)), LOW);
        delay(30);
      }
    }
    delay(100);
    j--;
  }
  SafeDel(&pin);
}

void Startup1()
{
  uint8_t pin[3] = {L_RED, L_GREEN, L_YELLOW};
  uint8_t j = 2;

  while (j != 0) {
    digitalWrite(pin[0], HIGH);
    delay(50);
    for (uint8_t i = 1; i < 3; i++) {
      wdt_reset();
      digitalWrite(pin[i], HIGH);
      delay(30);
      digitalWrite(pin[i + 1], HIGH);
      delay(20);
      if (j % 2 != 0) {
        digitalWrite(pin[i - 1], LOW);
        delay(30);
        wdt_reset();
      }
    }
    delay(100);
    wdt_reset();
    j--;
  }
  for (uint8_t i = 0; i < 3; i++) {
      digitalWrite(pin[i], LOW);
      wdt_reset();
    }
}

// to store and record pulse in EEPROM temporary
struct Pulse{
byte SB;
volatile uint32_t In = 0;//OUT FLOW
volatile uint32_t Out = 0;//OUT FLOW
}n, o;

void OUT_COUNT(){
  n.Out++;// total in // save in memory
}

void IN_COUNT(){
  n.In++;// total out // save in memory
}

float avg(float a, float b){
  //a-> old data, b-> new data
  // check new data for 0
  if(b == 0)
    return 0;
  else{
    return ((a + b) / 2.0);
  }
}

float GetLpm(uint32_t pin){
  // NOTE:- if digital not work then use analog
  volatile uint32_t Ht = pulseIn(pin, HIGH, PULSE_tout);
  volatile uint32_t Lt = pulseIn(pin, LOW, PULSE_tout);
  // volatile uint32_t t = Ht + Lt;
  return ((1000000UL/(Ht + Lt))/Lpm_ratio);
}

///2-pulse recorder
uint16_t add_SB = ADD_SB;//1;// start address of SB scanning
uint8_t nBlock = 93;//100;//94 capacity
uint16_t last_SB = ((nBlock*sizeof(n) + 1) - sizeof(n));

//////// new eeprom write
void data_write(uint32_t a, uint32_t b)//new kwh all
{
  Serial.print(F("Writing Pulse to ::"));
  EEPROM.update(add_SB, 0);//LAST WRITE SB TO 0
  //  Pulse new;
  n.SB = 1;
  n.In = a;
  n.Out = b;

  if (add_SB <= last_SB)//IF 1 CYCLE COMPLETE
    add_SB = add_SB + sizeof(n);
  else
    add_SB = ADD_SB;//RETURN BACK TO 1
  Serial.println(add_SB);
  wdt_reset();
  EEPROM.put(add_SB, n);
  // COPY WRITTEN PULSE TO NEW
  o.In = n.In;
  o.Out = n.Out;

  Serial.println(F("Written"));
}

void data_read()//read last written data from eeprom and update address
{
  //Serach for 1st 1 and update add_SB
  if(SHOW_SERIAL)
    Serial.print(F("Reading Pulse from ::"));
  for (add_SB = ADD_SB; add_SB <= last_SB; add_SB = add_SB + sizeof(o))
  {
    wdt_reset();
    if (EEPROM.read(add_SB) == 1)//
      goto done;
  }
done:
  //Write data to variable 'o'
  Serial.println(add_SB);
  EEPROM.get(add_SB, o);
  n.In = o.In;
  n.Out = o.Out;

  Serial.print(F("Reading Done"));
}

void save_Pulse(){
  wdt_reset();
  // check is data avail
  if((n.In - o.In) > 0 || (n.Out - o.Out) > 0){
    data_write(n.In, n.Out);
  }
  wdt_reset();
}

void ram() {
  Serial.print(F("RAM: "));
  Serial.println(freeRam());
}

float GetPCT(){
  // take ct current
  // take analog sample for 20ms
  float current[40];
  float percent = 0;
  float max = 0;

  for(int8_t i = 0; i < 40; i++){
    current[i] = AnalogPinVoltage(ICTP);
    delay(1);
  }

  for(uint16_t i = 0; i < 40; i++){
    if(current[i] > max){
      max = current[i];
    }
  }
  // convert into percentage
  percent = (max * 100/vCT_FS);//CHECK+ IT
  return percent;
}

// //EVENT
volatile bool event1 = false;
volatile bool event2 = false;

volatile bool is_upload_e1 = false;
volatile bool is_uploaded_e2 = false;

// // instantenious
// volatile float instantflow1 = 0;
// volatile float instantflow2 = 0;

// volatile float Oldflow1 = 0;
// volatile float Oldflow2 = 0;


// // avg
// volatile float flow1avg = 0;
// volatile float flow1avg_upload = 0;
// volatile float flow2avg = 0;
// volatile float TDSavg = 0;
// volatile float I_percent = 0;//ct current in % with FS 5A

// // time
volatile float run = 0;
volatile uint32_t s_t = 0;
volatile uint32_t e_t = 0;
volatile uint32_t _t_ = 0;

//FLOW
volatile float InLetFlow = 0;
volatile float OutLetFlow = 0;

//FLOW
volatile float OLD_InLetFlow = 0;
volatile float OLD_OutLetFlow = 0;

//FLOW AVG
volatile float InLetFlow_avg = 0;
volatile float OutLetFlow_avg = 0;

//OK
volatile float LitreIn = 0;
volatile float LitreOut = 0;
volatile float s_LitreIn = 0;

volatile float TDSavg = 0;

float GetTDS(){
  //read analog voltage and do multiply
  //tdsValue=(133.42*compensationVolatge*compensationVolatge*compensationVolatge - 255.86*compensationVolatge*compensationVolatge + 857.39*compensationVolatge)*0.5; //convert voltage value to tds value
  // float tds_loc = (133.42*AnalogPinVoltage(TDS_PIN, 10)*AnalogPinVoltage(TDS_PIN, 10)*AnalogPinVoltage(TDS_PIN, 10) - 255.86*AnalogPinVoltage(TDS_PIN, 10)*AnalogPinVoltage(TDS_PIN, 10) + 857.39*AnalogPinVoltage(TDS_PIN, 10))*0.5;
  float TDS = AnalogPinVoltage(vAI1, 100);
  return ((133.42*TDS*TDS*TDS - 255.86*TDS*TDS + 857.39*TDS)*0.5);//in ppm
}

void INflowAVG(){
  // if(event1 == true) {
  // NOTE:- if digital pulse read not work then use analog
  // cal flow1 in L/min
  InLetFlow = GetLpm(INflow);
  // cal flow1avg L/min
  if(OLD_InLetFlow == 0){
    OLD_InLetFlow = InLetFlow;
  }
  InLetFlow_avg = avg(OLD_InLetFlow, InLetFlow);
  // check avg value for zero and reset old to zero
  if(InLetFlow_avg == 0){
    OLD_InLetFlow = 0;
  }
// }
}

void updateDATA_IT_callback(void)
{
	// Serial.println(F("UPD-D"));
    // special care on doing avg
  wdt_reset();
  INflowAVG();


  // cal flow2    L/min
  OutLetFlow = GetLpm(OUTflow);
  // cal flow2avg L/min
  if(OLD_OutLetFlow == 0){
    OLD_OutLetFlow = OutLetFlow;
  }
  OutLetFlow_avg = avg(OutLetFlow_avg, OutLetFlow);
  // check avg value for zero and reset old to zero
  if(OutLetFlow_avg == 0){
    OutLetFlow_avg = 0;
  }

  // calc TDS
  TDSavg = avg(GetTDS(), GetTDS());
}

void SAVE_IT_callback(){
  //save data
  // Serial.println(F("S"));
  save_Pulse();
  //calc litre
  LitreOut = o.Out/PULSEperL;
  LitreIn = o.In/PULSEperL;
}

bool HTTPInit() {
    //  AT+HTTPTERM
    //  GSM.CheckCmd(ReadeepString(AT_) + ReadeepString(HTTP) + ReadeepString(TERM), ZF3E0, tout1);
    //  GSM.CheckCmd(&ReadeepString(AT_), ZF3E0, tout1);
    GSM.CheckCmd(F("AT+HTTPTERM"), ZF3E0, tout1);

    //  AT+HTTPINIT
    //  return GSM.CheckCmd(ReadeepString(AT_) + ReadeepString(HTTP) + ReadeepString(INIT), ZF3E0, tout1);
    //  return GSM.CheckCmd(&ReadeepString(AT_), ZF3E0, tout1);
    return GSM.CheckCmd(F("AT+HTTPINIT"), ZF3E0, tout1);
}

uint8_t HTTPsetup() {
  String Host = ReadeepString(S_HOST);
  if(Host == nullptr)
  return 0;
    //https://bhanu.free.beeceptor.com/G_POST
    //temp2239@gmail.com  - 1234567890
    // GSM.CheckCmd(F("AT+HTTPPARA=\"URL\",\"http://gprstest.free.beeceptor.com/G_POST\""), ZF3E0, tout1);

    //  AT+HTTPPARA="URL","http://103.233.79.197:8000/ADSmart.asmx/Demo1
    // GSM.CheckCmd(F("AT+HTTPPARA=\"URL\",\"http://demo5089036.mockable.io/G_TEST\""), ZF3E0, tout1);
    // GSM.CheckCmd(F("AT+HTTPPARA=\"URL\",\"http://bhanu.free.beeceptor.com/G_POST\""), ZF3E0, tout1);
    // GSM.CheckCmd(&ReadeepString(PARA_URL), ZF3E0, tout1);//SAVES

     //CHECK GSM TIME
    // AT+CNTP=\"time.google.com\",22
    // Serial.println(GSM.GetCmd(F("AT+CNTP=\"time.google.com\",22"), ZF3E0, tout1));
    GSM.GetCmd(F("AT+CNTP=\"time.google.com\",22"), ZF3E0, tout1);


    // AT+CNTP // sync time
    // Serial.println(GSM.GetCmd(F("AT+CNTP"), ZF3E0, tout1));
    GSM.GetCmd(F("AT+CNTP"), ZF3E0, tout1);

    // Serial.println(GSM.GetCmd(F("AT+CCLK?"), ZF3E0, tout1));
    GSM.GetCmd(F("AT+CCLK?"), ZF3E0, tout1);

    // AT+HTTPPARA=\"CID\",1\r\n")
    GSM.CheckCmd(F("AT+HTTPPARA =\"CID\",1"), ZF3E0, tout1);

    //if check for https: -> turn on SSL (AT+HTTPSSL=1) ->
    GSM.Println(F("AT+HTTPSSL=1"));
    // if(!CheckString(&Host, F("s://"), 4)){
    //   //not SSL
    //   GSM.Println("0");
    // }
    // else{
    //   GSM.Println("1");
    // }
    // GSM.CheckCmd(F("AT+HTTPSSL=1"), ZF3E0, tout1);
    // Serial.println(GSM.GetCmd(F("AT+HTTPSSL=1"), ZF0Eo1, tout1));

    // +HTTPACTION: <code>
    // <code>  605 SSL failed to establish channels
    //         606 SSL alert message with a level of fatal result in the immediate termination of the connection


    // "AT+HTTPPARA=\"URL\",\""
    GSM.Print(F("AT+HTTPPARA=\"URL\",\""));

    // <Host> - S_HOST (with http or https)
    // GSM.Print(F("http://demo5089036.mockable.io"));//READ FROM EEPROM
    GSM.Print(&Host);
    // GSM.Print(F("https://wsms.co.in/api/v1/867273021268029/telemetry"));//SET IMEI

    // <Method> - S_METHOD
    // GSM.Print(F("/G_TEST"));//READ FROM EEPROM
    GSM.Print(ReadeepString(S_METHOD));

    // "\""
    GSM.Println(F("\""));
    GSM.CheckCmd(F(""), ZF3E0, tout1);


  //AT+HTTPPARA ="REDIR",1 -> redirect flag
    // GSM.CheckCmd(F("AT+HTTPPARA =\"REDIR\",1"), ZF3E0, tout1);


    //    AT+HTTPPARA="CONTENT","application / x - www - form - urlencoded" //VVI
    // GSM.CheckCmd(F("AT + HTTPPARA = \"CONTENT\",\"application/x-www-form-urlencoded\""), ZF3E0, tout1);
    //  GSM.CheckCmd(&ReadeepString(PARA_CONTENT), ZF3E0, tout1);//SAVES

    // "AT+HTTPPARA=\"CONTENT\",\""
    GSM.Print(F("AT+HTTPPARA=\"CONTENT\",\""));

    // <content> - S_CONTENT
    // GSM.Print(F("application/x-www-form-urlencoded"));
    GSM.Print(ReadeepString(S_CONTENT));

    // "\""
    GSM.Println(F("\""));
    GSM.CheckCmd(F(""), ZF3E0, tout1);

    return 1;
}

uint8_t Req_UPLOAD(uint16_t l) {
    String st;
    st = F("AT+HTTPDATA=");
    st += (String)l;
    st += F(",10000");
    //  Serial.println(st);
    if (!GSM.CheckCmd(&st, F("DOW"), ZF3E0, tout1))
        return 0;
    return 1;
}

uint8_t HTTPstatus() {
    //  AT+HTTPSTATUS?
    // +HTTPSTATUS: POST,1<0-idle, 1-Recv.., 2-Sending>,0<finish>,241<remaining to be sent or recv>
    //  Serial.println(F("STATUS"));
    // delay(20);//relaxation
    uint32_t t = millis();
    // wait 20ms
    while((millis() - t) < 20);//test

    t = millis() / 100;
    while (GSM.Getuint8(F("AT+HTTPSTATUS?"), F(","), 1) != 0) {
        if (((millis() / 100) - t) > (toutSTATUS / 100))
            return 0;
    }
    return 1;
}

uint32_t Response() {
    // SAFELY Check for +HTTPACTION: 1<POST>,200<OK>,3<LEN>
    // Serial.println(GSM.GetCmd(F(""), F("+HTTP"), ZF0E0, toutHTTP));

    // +HTTPACTION: <code>
    // <code>  605 SSL failed to establish channels
    //         606 SSL alert message with a level of fatal result in the immediate termination of the connection


    //  Serial.println(GSM.GetCmd(F(""), F("\r"), ZF0E0, tout1));
    String st;
    st = GSM.GetCmd(F(""), F("ON:"), ZF0Eo1, toutHTTP);//+HTTPACTION:
    if(SHOW_SERIAL){
      Serial.print(F("Response()1: "));
      Serial.println(st);
    }
    //+HTTPACTION:
    if (!CheckString(&st, F("+HT"), 3)) { // && CheckString(&st, F(":"), 1)) {
        goto err;
    }
    st = GSM.GetCmd(F(""), F("\n"), ZF0Eo1, toutHTTP);//f2e01
    if(SHOW_SERIAL){
      Serial.print(F("Response()2: "));
      Serial.println(st);
    }
    //1,200,5
    if (!CheckString(&st, F(","), 1)) {//check two times ','
        goto err;
    }

    //extract useful data from ": 1,200,3"
    // CHECK method(OPTIONAL)
    //  Serial.println(GetInt(&st, F(" ")));//1<TYPE 0-GET, 1-POST>

    //  Serial.println(GetInt(&st, F(",")));//<HTTP STATUS REPLY>
    //  Serial.println(GetInt(&st, F(","), 2)); //<len>


    return ((GetInt(&st, F(","), 2) << 16) | GetInt(&st, F(",")));
    err:
    return 0;
}

uint8_t Reply(uint16_t allowed_len) {
    uint32_t r = Response();//0-15-> reply status, 16-31->len
    if (SHOW_SERIAL){
        Serial.print(F("RESPONSE: "));
        Serial.println(r, HEX);
    }
    // Return reply status ONLY IF LENTH IS <300
    // check reply status (MASK 0x00000FFC)
    //  r&0x00000FFC -> check series - 1xx, 2xx, 3xx, 4xx, 5xx, 6xx
    if (((r & 0x00000FFC) == 200)) {
        // r&0x00000003
        //200, 201, 202
        if((r & 0x00000003) > 2)
            return 0;
        // check suitable length
        r >>= 16;
        if((r & 0x0000FFFF) > allowed_len){
            return 0;
        }
    }
    else  if (((r & 0x00000FFF) == 603)) {
    ///IF DNS ERROR(603) close GPRS
    //AT+SAPBR=0,1 or AT+CIPSHUT
    GSM.CheckCmd(F("AT+SAPBR=0,1"), ZF3E0, tout1);
    }
    return 1;
}

uint8_t Uploded(){
    //{"success":true}
    // return 1;
    // if (SHOW_SERIAL) {
    //     Serial.println(F("READ"));
    //     Serial.println(GSM.GetCmd(F("AT+HTTPREAD"), ZF3E0, tout1));
    // }
    if(GSM.CheckCmd(F("AT+HTTPREAD"), F("ACK"), ZF1E0, 1000)){return 1;}
    return 0;
}

uint8_t get_u_retry()//MULTIPLE TIMES
{ uint8_t u_retry_var = EEPROM.read(U_RETRY);
  if (u_retry_var <= 10 && u_retry_var != 0)
    return u_retry_var;
  else
    return 10;
  //  Serial.print(u_retry_var);
  //  Serial.println(F("<--UPLOAD RETRY"));
}

void GSM_Heal() {
    GSM.Heal(RST);//Restrt rst pin 0-sw rst !0-hw reset // (-2)->SIM Not Ready (-1)-> Call Ready not found (0)-> !AT (1)-> GSM DEVICE READY
    GSM.Flush();
    if(SHOW_SERIAL){Serial.print(F("N/w "));}

    if (!GSM.Test(NWtest)) {
        if (SHOW_SERIAL){Serial.println(F("!K"));}

    }
    else {
        //    Serial.println(F("OK"));
          //  GSM.SetAPN(F("datamobile.ag"));//data mobile
        //    GSM.SetAPN();
        //    Serial.print(F("GPRS "));
        //    if (!GSM.Test(GPRStest))
        //      Serial.println(F("FAIL"));
        //    else
        //      Serial.println(F("OK"));
    }
    if (SHOW_SERIAL) {
        Serial.print(GSM.GetSignal(SigPct));
        Serial.println(F("%"));
        ram();
    }
    // GSM.SetAPN(F("datamobile.ag"));//data mobile
}

uint8_t UPLOAD_ENC_DATA_JSON(uint8_t event_type) {
    //if not data return
    digitalWrite(L_GREEN, LOW);//LED OFF
    // if (dlen == 0)
    //     goto fail;
    uint8_t Retry = get_u_retry();//from Eeeprom
    uint32_t time_format = 0;
    String st;
    uint32_t UNIX = 1600652429;
    beg:
    digitalToggleFast(PIN_GREEN);
    ram();
    // GSM.Heal(GSMHeal | 0x80, RST);
    //Serial.println(F("U HEAL"));
    GSM_Heal();
    //  //Serial.println(F("U..."));
    //  //Serial.println(GSM.GetSignal(SigPct));
    //CHECK GPRS
    digitalToggleFast(PIN_GREEN);
    //CPNNECT INTERNET
    if (!GSM.Internet()) {//0b01000000
        if (SHOW_SERIAL)
            //Serial.println(F("!g"));
       notGPRS--;
        //CHECK SIM OR HEAL GSM
        goto retry;
    }
    //sync time

    //  POST:
    //  SIZE- 850 OK
    digitalToggleFast(PIN_GREEN);
    if (!HTTPInit())
        goto retry;

    HTTPsetup();

    //calculate byte length of data
    //LEN_DELE = DEV=<2*2-Bytes>&DT=<2*4-Bytes>&d=<data-(dlen*2)>
    //Total len of frame = (2*dlen) + (LEN_DELE)
    // corrected json
    //     {
    // "dateTime": "2020-09-19T11:14:00.45+05:30",
    // "ph": 7,
    // "tds": 500,
    // "flowRate": 150,
    // "poweStatus": "Available",
    // "deliveryStatus":[
    // {
    // "block": "block_name",
    // "pressure": 10
    //  }
    // ]
    // }

    // st = F("{\n");
    // st += F("\"dateTime\":\"2020-09-19T11:14:00.45+05:30\",\n");
    // st += F("\"ph\": 7.0,\n");
    // st += F("\"tds\": 500,\n");
    // st += F("\"flowRate\": 150,\n");
    // st += F("\"poweStatus\": \"Available\",\n");
    // st += F("\"deliveryStatus\":[\n");
    // st += F("{\n");
    // st += F("\"block\": \"block_name\",\n");
    // st += F("\"pressure\": 10\n");
    // st += F("}\n");
    // st += F("]\n");
    // st += F("}\n");

  //   st = F("{\n");
  //   st += F("\"dateTime\":\"");
  //   // GET DATE AND TIME FROM MODULE
  //   // 2020-09-19T11:14:00.45+05:30
  //   // UnixToIso//but not +05:30
  //   UNIX = GSM.GetUnix();
  //   //CONVERT INTO ISO without add +5:30
  //   st += GetISO(UNIX);//test+ //left+
  //   st += F("\",\n");

  // if(event_type == 1){
  //   st += F("\"InLetFlow\": ");
  //   st += (String)InLetFlow_avg;
  //   st += F(",\n");

  //   st += F("\"TotalLitreIn\": ");
  //   st += (String)LitreIn;
  //   st += F(",\n");

  //   st += F("\"SessionLitreIn\": ");
  //   st += (String)Litre_e1;
  //   st += F(",\n");

  //   st += F("\"SessionRunMinute\": ");
  //   st += (String)(_t_/60.0);
  //   st += F(",\n");

  //   // st += F("\"TDS\": ");
  //   // st += (String)(TDSavg);
  //   // st += F(",\n");
  // }
  // else{

  //   st += F("\"OutLetFlow\": ");
  //   st += (String)OutLetFlow_avg;
  //   st += F(",\n");

  //   st += F("\"TotalLitreOut\": ");
  //   st += (String)LitreOut;
  //   st += F(",\n");

  //   st += F("\"TDSavg\": ");
  //   st += (String)TDSavg;
  //   st += F(",\n");
  // }
  //   // st += F("\"poweStatus\": \"Available\",\n");
  //   st += F("\"deliveryStatus\":[\n");
  //   st += F("{\n");
  //   st += F("\"block\": \"event1\",\n");
  //   st += F("\"pressure\": 10\n");
  //   st += F("}\n");
  //   st += F("]\n");
  //   st += F("}\n");

    st = F("{\n");
    st += F("\"dateTime\":\"");
    // GET DATE AND TIME FROM MODULE
    // 2020-09-19T11:14:00.45+05:30
    // UnixToIso//but not +05:30
    UNIX = GSM.GetUnix();
    //CONVERT INTO ISO without add +5:30
    st += GetISO(UNIX);//test+ //left+
    st += F("\",\n");

    st += F("\"SignalStrength\": ");
    st += (String)GSM.GetSignal(SigPct);
    st += F("%,\n");

  if(event_type == 1){
    st += F("\"InLetFlow\": ");
    st += (String)InLetFlow_avg;
    st += F(",\n");

    st += F("\"TotalLitreIn\": ");
    st += (String)LitreIn;
    st += F(",\n");

    st += F("\"SessionLitreIn\": ");
    st += (String)Litre_e1;
    st += F(",\n");

    st += F("\"SessionRunDuration\": \"");
    //CALC HH
    time_format = (_t_/3600UL);
    st += (String)time_format;//HH
    st += F(":");
    //CALC MM
    time_format = (_t_ % 3600UL);//MM AND SS
    time_format /= 60UL;//MM
    st += (String)time_format;//MM
    st += F(":");

    //CALC SS
    time_format = (_t_ % 3600UL);//MM AND SS
    time_format %= 60UL;//SS
    st += (String)time_format;//MM
    st += F("\"");
    st += F(",\n");

    // st += F("\"TDS\": ");
    // st += (String)(TDSavg);
    // st += F(",\n");
  }
  else if(event_type == 2){

    st += F("\"OutLetFlow\": ");
    st += (String)OutLetFlow_avg;
    st += F(",\n");

    st += F("\"TotalLitreOut\": ");
    st += (String)LitreOut;
    st += F(",\n");

    st += F("\"TDSavg\": ");
    st += (String)TDSavg;
    st += F(",\n");

    st += F("\"pHavg\": ");
    // st += (String)PHavg;
    st += F("7.0,\n");

    st += F("\"Pressure\": ");
    // st += (String)PHavg;
    st += F("0,\n");//EVERY MINUTE

    st += F("\"PowerStatus\": ");
    // st += (String)PHavg;
    st += F("\"ON\",\n");
  }
    // st += F("\"poweStatus\": \"Available\",\n");
    st += F("\"deliveryStatus\":[\n");
    st += F("{\n");
    st += F("\"block\": \"event");
    // 1//event_type
    st += (String)event_type;
    st += F("\"\n");
    st += F("}\n");
    st += F("]\n");
    st += F("}\n");

    //Serial.println(st);
    //    check for:-
    //    DOWNLOAD
    //  //Serial.println(F("HTTPDATA"));
    digitalToggleFast(PIN_GREEN);
    if (!Req_UPLOAD(LengthOf(&st))) { //DOWNLOAD
        goto retry;
    }

    //1997-07-16T19:20:30.45+01:00
    // BODY:-
    // {
    // "dateTime":"ISO Date Time format",
    // "ph": 7.0,
    // "tds": 500,
    // "flowRate": 100, //  ltr/min
    // "poweStatus": "Available", // opt - Available, Down, ....
    // "deliveryStatus":[
    // {
    //     "block": "block_name",
    //     "pressure": 12, // psi
    //     }
    // ]
    // }

    DGSM.Print(&st);

    // // {\n"dateTime":"
    //  DGSM.Print(F("{\n\"dateTime\":\""));
    //   // UNIX TIME 00000000
    //  DGSM.Print(h2s(String(0, HEX), 32));//unix time//4B
    //   // ",
    //  DGSM.Print(F("\",\n"));

    // //  "ph" :7.0,
    // DGSM.Print(F("\"ph\":"));
    //   // UNIX TIME 00000000
    //  DGSM.Print(h2s(String(0, HEX), 32));//unix time//4B
    //   // ",
    //  DGSM.Print(F("\","));

    // //ID=
    // DGSM.Print(F("ID="));
    // DGSM.Print(h2s(String(Read16Int(CLIENT_ID), HEX), 16));//2B
    // DGSM.Print(h2s(String(Read16Int(DEVICE_ID), HEX), 16));//2B
    // // DGSM.Print(h2s(String(1, HEX), 16));//2B
    // // DGSM.Print(h2s(String(1, HEX), 16));//2B

    // //&DT=
    // DGSM.Print(F("&DT="));
    // DGSM.Print(h2s(String(0, HEX), 32));//unix time//4B

    // //&G=
    // DGSM.Print(F("&D="));

    // //  AT+HTTPDATA=LEN,TIME
    // //  >>DOWNLOAD>>DATA
    // //  AT+HTTPDATA=335,1000
    // //convert ICT into IEEE754 HEX
    // DGSM.Print(h2s(String(0, HEX), 32));//ICT, 32
    // DGSM.Print(h2s(String(o.P1, HEX), 32));//P1, 32//PUT WHICH IS ACTUALLY WRITTEN
    // DGSM.Print(h2s(String(o.P2, HEX), 32));//P2, 32
    // //convert TDS vAI voltage
    // DGSM.Print(h2s(String(0, HEX), 16));//ICT, 32
    // //Directly send pressure
    // DGSM.Print(h2s(String(0, HEX), 16));//ICT, 32


    //    check for:-
    //    OK
    digitalToggleFast(PIN_GREEN);
    if (!GSM.CheckCmd(F(""), ZF3E0, tout1)) {
        goto retry;
    }

    //  AT+HTTPACTION=1
    //  //Serial.println(F("ACT=1"));
    digitalToggleFast(PIN_GREEN);
    if (!GSM.CheckCmd(F("AT+HTTPACTION=1"), ZF3E0, tout1)) {//POST
        goto retry;
    }
    //  AT+HTTPSTATUS?
    //  //Serial.println(F("STATUS"));
    //  //Serial.println(GSM.GetCmd(F("AT+HTTPSTATUS?"), ZF3E0, tout1));

    //check STATUS
    digitalToggleFast(PIN_GREEN);
    if (!HTTPstatus()) {
        goto retry;
    }

    //////////// VERY SENSITIVE PART /////////////
    /*
        Accepted:- 200, 202,
        Rejected:-
        ERROR:-
    */

    digitalToggleFast(PIN_GREEN);
    if (!Reply(1000)) {
        goto retry;
    }

    //read data if Reply() is ok
    // if(!Uploded()){
    //     goto retry;
    // }
    //ACCOTDING TO STATUS READ HTTP MSG

    // ok:
    if (SHOW_SERIAL)
        ram();
    digitalWrite(L_GREEN, LOW);//LED OFF
    return 1;

  retry:
    //  fail(UPLOAD);
    if (Retry > 0) {
      //CHECK BIT.11 THEN RETRY -= 2
      //    if (!((Response >> 11) & 0x01))//0x800
      // if (!(Response & 0x0800)) { //0x800
      //   Retry -= 2;
      //   // fail(UPLOAD);
      // }
      // else
      Retry--;
      //Serial.println(Retry);
      // //Serial.print(F("0x"));
      // //Serial.println(Response, HEX);
      // Response = 0;//reset response
      if(notGPRS <= 0){
        // RESET MODEM
        if(GSM.Restart(RST) != 0){//every 100ms//MEMORY FRAGMENTING
                GSM.Set();
          }
        // HEAL MODEM
        notGPRS = NOT_INTERNET_COUNT;
        //Serial.println(F("EXTREME INTERNET ERROR"));
      }

      goto beg;
    }

    // fail:
    digitalWrite(L_GREEN, LOW);//LED OFF
    //RESTART REQUEST
    return 0;
}

void Eeeprom_UPDATE(){
  String st;
    // Optional_qDEV
    // WriteeepString(S_Optional_qDEV, E_Optional_qDEV, F("PrismL1"));
        // MC: // MODBUS COMMUNICATION
    // //get
    // EEPROM.update(MOD_FUN, GetuInt8(data, 2)); //MOD_FUNCTION
    // //get
    // EEPROM.update(PARITY, GetuInt8(data, 3)); //MOD_PARITY
    // //get
    // EEPROM.update(MOD_BAUD, GetuInt8(data, 4));//MOD_BAUD

    // MP: //MODBUS PARAMETER
    //  //######################## Slave id-1   //Fixed
    // EEPROM.update(SLAVE1, GetuInt8(data, &from, 1)); //SID-1
    // Write16Int(MOD_ADD1, GetuInt(data, &from, 2)); //ADD-1
    // EEPROM.update(nPOLL1, GetuInt8(data, &from, 3)); //REG-1
    // //CAUSE 164 BYTE OF FLASH
    // //Slave id-2
    // c[0] = GetuInt8(data, &from, 4);
    // EEPROM.update(SLAVE2, (uint8_t)c[0]); //SID-2
    // if ((uint8_t)c[0] != 0) {
    //   Write16Int(MOD_ADD2, GetuInt(data, &from, 5)); //ADD-2
    //   EEPROM.update(nPOLL2, GetuInt8(data, &from, 6)); //REG-2
    // }
    // //SO ON

    // CR: //WiFi Connect Router
    // save:
    // //SAVE TO EEPROM-
    // WriteeepString(S_SSID, E_SSID, &ssid);  //WRITE SSID
    // WriteeepString(S_PASS, E_PASS, &password);  //WRITE KEY

    // SA: set access point
    // http://bhanu.free.beeceptor.com/G_POST
    // WriteeepString(S_HOST, E_HOST, F("http://demo5089036.mockable.io")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/G_SSLTEST")); //Method
    //  https://epaqtbbwt7.execute-api.ap-south-1.amazonaws.com/dev
    // WriteeepString(S_HOST, E_HOST, F("https://epaqtbbwt7.execute-api.ap-south-1.amazonaws.com")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/dev")); //Method

    //  https://wsms.co.in
    //  /api/v1/[IMEI_NUMBER]/telemetry
    //  AT+GSN -> GET IMEI(FAIL)  867273021268029
    WriteeepString(S_HOST, E_HOST, F("https://wsms.co.in")); //Host
    // st = F("/api/v1/");https://wsms.co.in/api/v1/867273021268029/telemetry
    // WriteeepString(S_METHOD, E_METHOD, F("/api/v1/867273021268029/telemetry")); //Method
    //  WriteeepString(S_METHOD, E_METHOD, F("/api/v1/865472039224295/telemetry")); //Method//site-1
     WriteeepString(S_METHOD, E_METHOD, F("/api/v1/864764034145538/telemetry")); //Method//WILL BE IN site-2

    // http://86.96.203.99:81/api/parsermbus
    // WriteeepString(S_HOST, E_HOST, F("http://86.96.203.99:81")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/api/parsermbus")); //Method

    // WriteeepString(S_HOST, E_HOST, F("http://bhanu.free.beeceptor.com")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/G_POST")); //Method

    // application/x-www-form-urlencoded
    // WriteeepString(S_CONTENT, E_CONTENT, F("application/x-www-form-urlencoded")); //Content Type

    //text/json
    WriteeepString(S_CONTENT, E_CONTENT, F("text/json"));

    // SI: //SET ID
    //SAVE TO EEPROM
    // Write16Int(CLIENT_ID, 10);
    // Write16Int(DEVICE_ID, 1);

    // DU: //data upload time and retry
    EEPROM.update(UPLOAD_d, (20 / 5)); //UPLOAD
    //upload retry
    EEPROM.update(U_RETRY, 10);

    // DR: //DATA RETRY
    // EEPROM.update(MOD_RETRY, 3); //mod_retry

    //SSL: ON or OFF

    // DT: // DEVICE TEST

}

void Eeeprom_SHOW(){
  // Serial.println(ReadeepString(S_Optional_qDEV));
/*//460 BYTE PROM
    //EEPROM TEST
    Serial.println(EEPROM.read(SLAVE1));
    Serial.println(EEPROM.read(SLAVE2));
    Serial.println(EEPROM.read(SLAVE3));
    Serial.println(EEPROM.read(SLAVE4));
    Serial.println(get_mod_baud() * 100);
    Serial.println(get_mod_parity());
    Serial.println(get_mod_fun());
    Serial.println(get_mod_retry());
    //4*Slave, Add, nPoll
  */
  //Upload Duration
  // Serial.println(get_upload() * 5);
  // Serial.println(get_client_id());
  // Serial.println(get_device_id());
//   Serial.println(get_port());

  //  / / String
//   Serial.println(ReadeepStringUpto(S_SSID, '\0'));
//   Serial.println(ReadeepStringUpto(S_PASS, '\0'));
  Serial.println(ReadeepString(S_HOST));
//   Serial.println(ReadeepStringUpto(S_HOST, ':'));
  Serial.println(ReadeepString(S_METHOD));
  Serial.println(ReadeepString(S_CONTENT));

}

float GetICT(){
  // take ct current
  // take analog sample for 20ms
  float current[40];
  float percent = 0;
  float max = 0;

  for(int8_t i = 0; i < 40; i++){
    current[i] = AnalogPinVoltage(PA_0, 10);
    delay(1);
  }

  for(uint16_t i = 0; i < 40; i++){
    if(current[i] > max){
      max = current[i];
    }
  }
  // convert into percentage
  percent = (max * 100/vCT_FS);//CHECK+ IT
  return percent;
}


void setup() {
  // put your setup code here, to run once:
  // WATCH DOG SETUP
  IWatchdog.reload();//RESET WATCHDOG
  IWatchdog.clearReset();
  IWatchdog.begin(WDTus);

  //flow
  pinMode(INflow, INPUT_PULLDOWN);
  pinMode(OUTflow, INPUT_PULLDOWN);
  pinMode(vAI1, INPUT_ANALOG);
  pinMode(vAI2, INPUT_ANALOG);
  pinMode(ICTP, INPUT_ANALOG);

  //LED
  pinMode(L_RED, OUTPUT);
  pinMode(L_GREEN, OUTPUT);
  pinMode(L_YELLOW, OUTPUT);


  Serial.begin(9600);//SERIAL
  _SERIAL.begin(gsmbaud);//GSM

  Eeeprom_UPDATE();

  //For PulseIN AND PulseOUT
  // data_write(0, 0);//reset from serial
  data_read();

  //calc litre
  LitreOut = o.Out/PULSEperL;
  LitreIn = o.In/PULSEperL;

  //flow
  attachInterrupt(digitalPinToInterrupt(INflow), IN_COUNT, P_MODE);
  attachInterrupt(digitalPinToInterrupt(OUTflow), OUT_COUNT, P_MODE);

  Serial.println(F("HI"));

  GSM.Set(ONE_TIME_BASIC);
  wdt_reset();
  GSM_Heal();
  wdt_reset();

  //connect internet
  // GSM.Internet();

  e2_upload_timer = (millis()/1000) - EVENT2_TOUT;

}


void loop() {
  Startup1();
  wdt_reset();
  float I_percent = GetPCT();
  while(1){
      I_percent = GetPCT();
      wdt_reset();
      if(millis()/100 - save_timer > 50){
          save_timer = millis()/100;
          SAVE_IT_callback();// every 5 sec
          Serial.print(F("I%= "));
          Serial.println(I_percent);
        }
        Serial.print(F("I%= "));
        Serial.println(I_percent);
      // put your main code here, to run repeatedly:
      updateDATA_IT_callback();
      // event-1 check
        // if((I_percent > Lth) && (I_percent <= Uth)){
        if(I_percent > Uth){
          Serial.println(F("EVENT1 check"));
          Serial.print(F("I%= "));
          Serial.println(I_percent);

            if(event1 == false){//1ST TIME TRIGGER
              // new event
              I_percent = GetPCT();
              wdt_reset();
              if(wait_pump == 0){
                wait_pump = (millis()/1000);
                digitalWrite(L_RED, HIGH);
              }
              if(((millis()/1000) - wait_pump) < (pump_wait/1000)){
                goto end0;
              }
              digitalWrite(L_RED, LOW);
              // HAL_Delay(pump_wait);// wait for stability//or use normal delay//instead use wait timer
              wdt_reset();
              // wait for stablization
              // if((I_percent > Lth) && (I_percent <= Uth)){
                  if(I_percent > Uth){
                  // record satart time
                  // event started
                  digitalWrite(L_YELLOW, HIGH);
                  event1 = true;
                  wait_pump = 0;
                  //recored start time for run hour in second
                  s_t = millis()/ratio_e1;
                  //record start litre
                  s_LitreIn = o.In/PULSEperL;
                  //flow average
                  updateDATA_IT_callback();
              }

            }
            // else{
                // recording will happen in background
            // }
        }
            else {//if((I_percent <= Lth) && (I_percent > Uth)){
              // motor is in invalid state
              // reset event
              // check event1 for true
              wait_pump = 0;
              if(event1 == true){
                event1 = false;//EVENT CLOSED
                e_t = millis()/ratio_e1;
                //motor run hour
                _t_ = e_t - s_t;// total on time in second
                // LitreIn = flow1avg * (_t_ / 60.0);
                //litre by event
                if(LitreIn <= s_LitreIn){//VERIFY
                  Litre_e1 = s_LitreIn;
                }
                else{
                  Litre_e1 = LitreIn - s_LitreIn;//litre in event-1
                }
                //total litre
                //flow average
                // store to eeprom and upload
                // upload data//left+
                digitalWrite(L_YELLOW, LOW);
                UPLOAD_ENC_DATA_JSON(1);
                is_upload_e1 = true;
          }
        }
    end0:
        updateDATA_IT_callback();
        if(millis()/100 - save_timer > 50){
          SAVE_IT_callback();// every 5 sec
        save_timer = millis()/100;
        }
        //event-2
      if((millis()/1000 - e2_upload_timer) > (EVENT2_TOUT)){// 60s//or 1hr 3600
        e2_upload_timer = millis()/1000;
        Serial.println(F("EVENT2"));
        UPLOAD_ENC_DATA_JSON(2);
      }
      wdt_reset();
  }

}