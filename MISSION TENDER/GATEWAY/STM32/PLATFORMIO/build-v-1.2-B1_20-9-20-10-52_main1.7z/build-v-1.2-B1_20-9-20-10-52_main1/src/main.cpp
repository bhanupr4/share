#include <Arduino.h>
#include <BhanuSTM32adc.h>
#include <BhanuSTM32EEPROM.h>
#include <BhanuSTM32GSM.h>
#include <SoftwareSerial.h>

// constants
#define vCT_FS 2.828427125


#define SHOW_SERIAL 0

//CONFIG
#define WDT   4UL//IN SEC
#define WDTms WDT*1000UL
#define WDTus WDTms*1000UL

#define UPLOAD_MULT   ((1000/RATIO_100) *5)
#define UPLOAD_OFFSET 800/RATIO_100//ms offset//0.5sec OFFSET

#define UPLOAD_MULT   ((1000/RATIO_100) *5)
#define UPLOAD_OFFSET 800/RATIO_100//ms offset//0.5sec OFFSET

#define UPLOAD_d  1   //*5sec
#define U_RETRY   3

#define ADD_SB  (E_CONTENT + 1)

#define S_HOST    11
#define E_HOST                81
#define S_METHOD  82
#define E_METHOD              132
#define S_CONTENT 133
#define E_CONTENT             173// careful here

#define ADD_SB  (E_CONTENT + 1)

////// Temporary CONSTANT /////
#define RETRY 5
#define ACK_LEN_LIMIT 1000

//GSM
#define gsmbaud 115200//19200
#define tout1 100
#define toutHTTPDATA 5000
#define toutSTATUS   20000//8000
#define toutHTTP     6000
#define NOT_INTERNET_COUNT  20
#define DEBUG       0b00110001 //on error quick get error
//#define error       0b00110000
#define nZF1Eo1     0b10010001
#define ZF1Eo1      0b00010001
#define nZF1E0      0b10010000
#define ZF3oEo1     0b00111001
#define ZF3Eo1      0b00110001
#define ZF0Eo1      0b00000001
#define ZF3oE0      0b00111000
#define ZF3E0       0b00110000
#define ZF1E0       0b00010000
#define ZF0E0       0b00000000
#define nZF3oEo1    0b10111001
#define nZF3Eo1     0b10110001
#define nZF3oE0     0b10111000
#define nZF3E0      0b10110000
#define GSMtest     0b00001111
#define GPRStest    0b00001000
#define SIMtest     0b00000010
#define NWtest      0b00000100
#define CCLKtest    0b00010000
#define HouUnix     0b00111100
#define MinUnix     0b00111110
#define SecUnix     0b00111111
#define SAP1APN     0b00000010
#define CSTTAPN     0b00000100
#define BOTHAPN     0b00000110
#define oSAP1APN    0b00000011
#define oCSTTAPN    0b00000101
#define oBOTHAPN    0b00000111
#define GSMHeal     0b00000011//at + sim
#define WiFiHeal    0b00000001//at
#define SwRST       0b00000000
#define SigPct      0b00000000
#define Sigusdb     0b00000001
#define Sigsdb      0b10000001

#define ONE_TIME    0x8000
#define ATV1        0x0001
#define CREG0       0x0002
#define CSDT1       0x0004
#define CSCLK0      0x0008
#define CMGF1       0x0010
#define SLED        0x0020
#define CMGDAall    0x0040
#define CNMI        0x0080//VVI FOR SMS//New SMS Message Indications
#define ATE0        0x0800

#define ONE_TIME_BASIC  0x88BF //(ONE_TIME|ATV1|CREG0|CSDT1|CSCLK0|CMGF1|SLED|CNMI|ATE0)

#define SMEM_TOTAL    0
#define SMEM_SEND     1
#define SMEM_RECEIVE  2

// #define USART_RX_BUF_SIZE 16
// #define USART_TX_BUF_SIZE 16

// pins connection
// communication
#define _SERIAL Serial1//gsm
#undef Serial
#define Serial SERIAL_//serial
#define DGSM GSM
#define RX PB8//16//PB6//SERIAL RX
#define TX PB9//17//PB7// SERIAL TX

#define RST PA8//PB5//6
// pins
  // sensors
#define VREF readVdd()
#define O6      PA_0
#define O5      PA_1
#define O4      PA_3
#define O3      PA_2
#define CT_out  PA_0
#define Trig    O3
#define IN5     PA_5
#define IN6     PA_6

// STORAGE
#define MEM_DI  PB_15
#define MEM_DO  PB_14
#define MEM_CLK PB_13
#define MEM_RST PB_2
#define MEM_WP  PB_1
#define MEM_CS  PB_0

//LED
#define L_GREEN   PA_7
#define L_RED     PA_4
#define L_YELLOW  PB_11
#define U_LED     L_GREEN
#define S_LED     L_YELLOW
#define D_LED     L_RED

#define PULSE1  PA5
#define PULSE2  PA6

#define ratio_e1  1000;

// constant tout
#define PULSE_tout  100000UL//in us
// in percentage
#define Lth 0
#define Uth 50

// gsm
volatile uint16_t count = 0;


uint32_t timer = 0;

// uint8_t *data;//dynamic data pointer

SoftwareSerial SERIAL_(RX, TX);//(RX,TX)
// set RX and TX pins
// HardwareSerial Serial2(PA3, PA2);
// HardwareSerial Serial1(PB7, PB6);//ALREADY DEFINED, ONLY CAN CHANGE PIN

// BhanuSTM32GSM GSM(sim800l);//type-Auto-0 OR GSM-1 OR ESP-2 OR ETHERNET-3 OR LORA-4 etc
BhanuSTM32GSM GSM(_SERIAL, Serial);//(GSM,Serial)

void GSM_Heal();
void ram();
void Sdebug();

void ram() {
  Serial.print(F("RAM: "));
  Serial.println(freeRam());
}

  TIM_TypeDef *Instance1 = TIM3;
  TIM_TypeDef *Instance2 = TIM2;
  TIM_TypeDef *Instance3 = TIM1;
  TIM_TypeDef *Instance4 = TIM4;

  // Instantiate HardwareTimer object. Thanks to 'new' instanciation, HardwareTimer is not destructed when setup() function is finished.
  HardwareTimer *updateDATA = new HardwareTimer(Instance1);
  HardwareTimer *MotorI = new HardwareTimer(Instance2);
  HardwareTimer *EVENT1 = new HardwareTimer(Instance3);
  HardwareTimer *MyTim4 = new HardwareTimer(Instance4);

// timer
#define updateDATA_FREQ 5 // in Hz
#define MotorI_FREQ     1// in Hz//20
#define EVENT1_FREQ     2

//EVENT
volatile bool event1 = false;
volatile bool event2 = false;

volatile bool is_upload_e1 = false;


// instantenious
volatile float instantflow1 = 0;
volatile float instantflow2 = 0;

volatile float Oldflow1 = 0;
volatile float Oldflow2 = 0;


// avg
volatile float flow1avg = 0;
volatile float flow1avg_upload = 0;
volatile float flow2avg = 0;
volatile float TDSavg = 0;
volatile float I_percent = 0;//ct current in % with FS 5A

// time
volatile float run = 0;
volatile float s_t = 0;
volatile float e_t = 0;
volatile float _t_ = 0;

volatile float LitreIn = 0;
volatile float LitreOut = 0;

int8_t notGPRS = NOT_INTERNET_COUNT;

// uint32_t pi1 = digitalRead(IN5);
// uint32_t pi2 = digitalRead(IN6);


float GetLpm(uint32_t pin){
  // NOTE:- if digital not work then use analog
  volatile uint32_t Ht = pulseIn(pin, HIGH, PULSE_tout);
  volatile uint32_t Lt = pulseIn(pin, LOW, PULSE_tout);
  // volatile uint32_t t = Ht + Lt;
  return ((1000000UL/(Ht + Lt))/7.50);
}

float avg(float a, float b){
  //a-> old data, b-> new data
  // check new data for 0
  if(b == 0)
    return 0;
  else{
    return ((a + b) / 2.0);
  }
}

float GetTDS(){
  // read TDS and set multiplication
  return 0;
}

void updateDATA_IT_callback(void)
{
	//Serial.println(F("UPDATE-D"));
    // special care on doing avg
if(event1 == true) {
  // NOTE:- if digital pulse read not work then use analog
  // cal flow1 in L/min
  instantflow1 = GetLpm(PULSE1);
  // cal flow1avg L/min
  if(Oldflow1 == 0){
    Oldflow1 = instantflow1;
  }
  flow1avg = avg(Oldflow1, instantflow1);
  // check avg value for zero and reset old to zero
  if(flow1avg == 0){
    Oldflow1 = 0;
  }
}


  // cal flow2    L/min
  instantflow2 = GetLpm(PULSE2);
  // cal flow2avg L/min
  if(Oldflow2 == 0){
    Oldflow2 = instantflow2;
  }
  flow2avg = avg(Oldflow2, instantflow2);
  // check avg value for zero and reset old to zero
  if(flow2avg == 0){
    Oldflow2 = 0;
  }

  // cal TDS
  TDSavg = GetTDS();
}

float GetICT(){
  // take ct current
  // take analog sample for 20ms
  float current[40];
  float percent = 0;
  float max = 0;

  for(uint16_t i = 0; i <= 40; i++){
    current[i] = AnalogPinVoltage(PA_0, 10);
    delay(1);
  }

  for(uint16_t i = 0; i <= 40; i++){
    if(current[i] > max){
      max = current[i];
    }
  }
  // convert into percentage
  percent = (max * 100/vCT_FS);//CHECK+ IT
  return percent;
}

void MotorI_IT_callback(){
  // GET CT current input voltage
  // calc I_percet
    // NOTE:- if event is just started then wait for new current in main loop
    //Serial.println(F("MOTOR-T"));
    I_percent = GetICT();
}

void Event1_IT_callback(){
  // GET CT current input voltage
  // calc I_percet
    // NOTE:- if event is just started then wait for new current in main loop
    //Serial.println(F("EVENT-1"));
    if((I_percent > Lth) && (I_percent <= Uth)){
      digitalToggleFast(L_RED);
        if(event1 == false){
          // new event
          delay(1000);
          // wait for stablization
          if((I_percent >= Lth) && (I_percent <= Uth)){
              // record satart time
              // event started
              event1 = true;
              s_t = millis()/ratio_e1;
          }

        }
        // else{
            // recording will happen in background
        // }
    }
    else {//if((I_percent <= Lth) && (I_percent > Uth)){
      // motor is in invalid state
      // reset event
      // check event1 for true
      if(event1 == true){
        event1 = false;
        flow1avg_upload = flow1avg;
        e_t = millis()/ratio_e1;
        _t_ = e_t - s_t;// total on time in second
        LitreIn = flow1avg * (_t_ / 60.0);
        // store to eeprom and upload
        // upload data//left+
        is_upload_e1 = true;

      }
    }
}

/////////////////////// upload GPRS /////////////

bool HTTPInit() {
    //  AT+HTTPTERM
    //  GSM.CheckCmd(ReadeepString(AT_) + ReadeepString(HTTP) + ReadeepString(TERM), ZF3E0, tout1);
    //  GSM.CheckCmd(&ReadeepString(AT_), ZF3E0, tout1);
    GSM.CheckCmd(F("AT+HTTPTERM"), ZF3E0, tout1);

    //  AT+HTTPINIT
    //  return GSM.CheckCmd(ReadeepString(AT_) + ReadeepString(HTTP) + ReadeepString(INIT), ZF3E0, tout1);
    //  return GSM.CheckCmd(&ReadeepString(AT_), ZF3E0, tout1);
    return GSM.CheckCmd(F("AT+HTTPINIT"), ZF3E0, tout1);
}

uint8_t HTTPsetup() {
  String Host = ReadeepString(S_HOST);
  if(Host == nullptr)
  return 0;
    //https://bhanu.free.beeceptor.com/G_POST
    //temp2239@gmail.com  - 1234567890
    // GSM.CheckCmd(F("AT+HTTPPARA=\"URL\",\"http://gprstest.free.beeceptor.com/G_POST\""), ZF3E0, tout1);

    //  AT+HTTPPARA="URL","http://103.233.79.197:8000/ADSmart.asmx/Demo1
    // GSM.CheckCmd(F("AT+HTTPPARA=\"URL\",\"http://demo5089036.mockable.io/G_TEST\""), ZF3E0, tout1);
    // GSM.CheckCmd(F("AT+HTTPPARA=\"URL\",\"http://bhanu.free.beeceptor.com/G_POST\""), ZF3E0, tout1);
    // GSM.CheckCmd(&ReadeepString(PARA_URL), ZF3E0, tout1);//SAVES

     //CHECK GSM TIME
    // AT+CNTP=\"time.google.com\",22
    Serial.println(GSM.GetCmd(F("AT+CNTP=\"time.google.com\",22"), ZF3E0, tout1));

    // AT+CNTP // sync time
    Serial.println(GSM.GetCmd(F("AT+CNTP"), ZF3E0, tout1));

    Serial.println(GSM.GetCmd(F("AT+CCLK?"), ZF3E0, tout1));

    // AT+HTTPPARA=\"CID\",1\r\n")
    GSM.CheckCmd(F("AT+HTTPPARA =\"CID\",1"), ZF3E0, tout1);

    //if check for https: -> turn on SSL (AT+HTTPSSL=1) ->
    GSM.Println(F("AT+HTTPSSL=1"));
    // if(!CheckString(&Host, F("s://"), 4)){
    //   //not SSL
    //   GSM.Println("0");
    // }
    // else{
    //   GSM.Println("1");
    // }
    // GSM.CheckCmd(F("AT+HTTPSSL=1"), ZF3E0, tout1);
    // Serial.println(GSM.GetCmd(F("AT+HTTPSSL=1"), ZF0Eo1, tout1));

    // +HTTPACTION: <code>
    // <code>  605 SSL failed to establish channels
    //         606 SSL alert message with a level of fatal result in the immediate termination of the connection


    // "AT+HTTPPARA=\"URL\",\""
    GSM.Print(F("AT+HTTPPARA=\"URL\",\""));

    // <Host> - S_HOST (with http or https)
    // GSM.Print(F("http://demo5089036.mockable.io"));//READ FROM EEPROM
    GSM.Print(&Host);
    // GSM.Print(F("https://wsms.co.in/api/v1/867273021268029/telemetry"));//SET IMEI

    // <Method> - S_METHOD
    // GSM.Print(F("/G_TEST"));//READ FROM EEPROM
    GSM.Print(ReadeepString(S_METHOD));

    // "\""
    GSM.Println(F("\""));
    GSM.CheckCmd(F(""), ZF3E0, tout1);


  //AT+HTTPPARA ="REDIR",1 -> redirect flag
    // GSM.CheckCmd(F("AT+HTTPPARA =\"REDIR\",1"), ZF3E0, tout1);


    //    AT+HTTPPARA="CONTENT","application / x - www - form - urlencoded" //VVI
    // GSM.CheckCmd(F("AT + HTTPPARA = \"CONTENT\",\"application/x-www-form-urlencoded\""), ZF3E0, tout1);
    //  GSM.CheckCmd(&ReadeepString(PARA_CONTENT), ZF3E0, tout1);//SAVES

    // "AT+HTTPPARA=\"CONTENT\",\""
    GSM.Print(F("AT+HTTPPARA=\"CONTENT\",\""));

    // <content> - S_CONTENT
    // GSM.Print(F("application/x-www-form-urlencoded"));
    GSM.Print(ReadeepString(S_CONTENT));

    // "\""
    GSM.Println(F("\""));
    GSM.CheckCmd(F(""), ZF3E0, tout1);

    return 1;
}

uint8_t Req_UPLOAD(uint16_t l) {
    String st;
    st = F("AT+HTTPDATA=");
    st += (String)l;
    st += F(",10000");
    //  Serial.println(st);
    if (!GSM.CheckCmd(&st, F("DOW"), ZF3E0, tout1))
        return 0;
    return 1;
}

uint8_t HTTPstatus() {
    //  AT+HTTPSTATUS?
    // +HTTPSTATUS: POST,1<0-idle, 1-Recv.., 2-Sending>,0<finish>,241<remaining to be sent or recv>
    //  Serial.println(F("STATUS"));
    // delay(20);//relaxation
    uint32_t t = millis();
    // wait 20ms
    while((millis() - t) < 20);//test

    t = millis() / 100;
    while (GSM.Getuint8(F("AT+HTTPSTATUS?"), F(","), 1) != 0) {
        if (((millis() / 100) - t) > (toutSTATUS / 100))
            return 0;
    }
    return 1;
}

uint32_t Response() {
    // SAFELY Check for +HTTPACTION: 1<POST>,200<OK>,3<LEN>
    // Serial.println(GSM.GetCmd(F(""), F("+HTTP"), ZF0E0, toutHTTP));

    // +HTTPACTION: <code>
    // <code>  605 SSL failed to establish channels
    //         606 SSL alert message with a level of fatal result in the immediate termination of the connection


    //  Serial.println(GSM.GetCmd(F(""), F("\r"), ZF0E0, tout1));
    String st;
    st = GSM.GetCmd(F(""), F("ON:"), ZF0Eo1, toutHTTP);//+HTTPACTION:
    Serial.print(F("Response()1: "));
    Serial.println(st);
    //+HTTPACTION:
    if (!CheckString(&st, F("+HT"), 3)) { // && CheckString(&st, F(":"), 1)) {
        goto err;
    }
    st = GSM.GetCmd(F(""), F("\n"), ZF0Eo1, toutHTTP);//f2e01
    Serial.print(F("Response()2: "));
    Serial.println(st);
    //1,200,5
    if (!CheckString(&st, F(","), 1)) {//check two times ','
        goto err;
    }

    //extract useful data from ": 1,200,3"
    // CHECK method(OPTIONAL)
    //  Serial.println(GetInt(&st, F(" ")));//1<TYPE 0-GET, 1-POST>

    //  Serial.println(GetInt(&st, F(",")));//<HTTP STATUS REPLY>
    //  Serial.println(GetInt(&st, F(","), 2)); //<len>


    return ((GetInt(&st, F(","), 2) << 16) | GetInt(&st, F(",")));
    err:
    return 0;
}

uint8_t Reply(uint16_t allowed_len) {
    uint32_t r = Response();//0-15-> reply status, 16-31->len
    if (SHOW_SERIAL){
        Serial.print(F("RESPONSE: "));
        Serial.println(r, HEX);
    }
    // Return reply status ONLY IF LENTH IS <300
    // check reply status (MASK 0x00000FFC)
    //  r&0x00000FFC -> check series - 1xx, 2xx, 3xx, 4xx, 5xx, 6xx
    if (((r & 0x00000FFC) == 200)) {
        // r&0x00000003
        //200, 201, 202
        if((r & 0x00000003) > 2)
            return 0;
        // check suitable length
        r >>= 16;
        if((r & 0x0000FFFF) > allowed_len){
            return 0;
        }
    }
    else  if (((r & 0x00000FFF) == 603)) {
    ///IF DNS ERROR(603) close GPRS
    //AT+SAPBR=0,1 or AT+CIPSHUT
    GSM.CheckCmd(F("AT+SAPBR=0,1"), ZF3E0, tout1);
    }
    return 1;
}

uint8_t Uploded(){
    //{"success":true}
    // return 1;
    // if (SHOW_SERIAL) {
    //     Serial.println(F("READ"));
    //     Serial.println(GSM.GetCmd(F("AT+HTTPREAD"), ZF3E0, tout1));
    // }
    if(GSM.CheckCmd(F("AT+HTTPREAD"), F("ACK"), ZF1E0, 1000)){return 1;}
    return 0;
}

// void Sdebug()
// {
//     if (GSM.available() > 0)
//     {
//         Serial.println(F("Reading.."));
//         String st = GSM.ReadUpto(F("OK"), 3, 2);
//         Serial.println(CheckString(&st, F("OK"), 0));
//         Serial.println(st);
//         //    for (uint16_t i = 0; i < 49; i++)
//         //    { Serial.print(F("["));
//         //      Serial.print(i);
//         //      Serial.print(F("]="));
//         //      Serial.println((byte)st[i], HEX);
//         //    }
//         //    ntp = st;//temporary
//         //    Serial.println(ntp);
//     }
//     if (Serial.available() > 0) {
//         String st;
//         st.reserve(2000);
//         st = Serial.readString();
//         if (CheckString(&st, F("0x"), 2) || CheckString(&st, F("0X"), 2)) {
//             uint8_t index = CheckString(&st, F("0"), 1);
//             index += 2;
//             uint8_t d = 0;
//             //      Serial.println(st[index]);
//             if ((byte)st[index] >= 48 && (byte)st[index] <= 57) {
//                 d |= (byte)(st[index] - 48);
//             }
//             else if ((byte)st[index] >= 65 && (byte)st[index] <= 70) {
//                 d |= (byte)(st[index] - 55);
//             }
//             else if ((byte)st[index] >= 97 && (byte)st[index] <= 102) {
//                 d |= (byte)(st[index] - 87);
//             }
//             d = d << 4;
//             index++;
//             //      Serial.println(st[index]);
//             //      Serial.println(d, HEX);
//             if ((byte)st[index] >= 48 && (byte)st[index] <= 57) {
//                 d |= (byte)(st[index] - 48);
//             }
//             else if ((byte)st[index] >= 65 && (byte)st[index] <= 70) {
//                 d |= (byte)(st[index] - 55);
//             }
//             else if ((byte)st[index] >= 97 && (byte)st[index] <= 102) {
//                 d |= (byte)(st[index] - 87);
//             }
//             //      Serial.println(d, HEX);
//             GSM.write(d);
//         }
//         else {
//             if (CheckString(&st, F("C_"), 2)) {
//                 U_TEST_();
//                 return;
//             }
//             else if (CheckString(&st, F("CON"), 3) || CheckString(&st, F("con"), 3)) {
//                 ram();
//                 U_TEST(1);
//                 return;
//             }
//             Serial.println(st);

//             //      GSM.println(st);
//             st = GSM.GetCmd(&st, F("OK"), ZF1Eo1, 5000);
//             Serial.println(st);
//         }
//     }
// }

uint8_t get_u_retry()//MULTIPLE TIMES
{ uint8_t u_retry_var = EEPROM.read(U_RETRY);
  if (u_retry_var <= 10 && u_retry_var != 0)
    return u_retry_var;
  else
    return 10;
  //  Serial.print(u_retry_var);
  //  Serial.println(F("<--UPLOAD RETRY"));
}

void GSM_Heal() {
    GSM.Heal(RST);//Restrt rst pin 0-sw rst !0-hw reset // (-2)->SIM Not Ready (-1)-> Call Ready not found (0)-> !AT (1)-> GSM DEVICE READY
    GSM.Flush();
    if(SHOW_SERIAL){Serial.print(F("N/w "));}

    if (!GSM.Test(NWtest)) {
        if (SHOW_SERIAL){Serial.println(F("!K"));}

    }
    else {
        //    Serial.println(F("OK"));
        //    GSM.SetAPN(F("bsnlnet"));
        //    GSM.SetAPN();
        //    Serial.print(F("GPRS "));
        //    if (!GSM.Test(GPRStest))
        //      Serial.println(F("FAIL"));
        //    else
        //      Serial.println(F("OK"));
    }
    if (SHOW_SERIAL) {
        Serial.print(GSM.GetSignal(SigPct));
        Serial.println(F("%"));
        ram();
    }
}

uint8_t UPLOAD_ENC_DATA_JSON(uint8_t event_type) {
    //if not data return
    // if (dlen == 0)
    //     goto fail;
    uint8_t Retry = get_u_retry();//from Eeeprom
    String st;
    uint32_t UNIX = 1600652429 ;
    beg:
    digitalToggleFast(L_GREEN);
    ram();
    // GSM.Heal(GSMHeal | 0x80, RST);
    //Serial.println(F("U HEAL"));
    GSM_Heal();
    //  //Serial.println(F("U..."));
    //  //Serial.println(GSM.GetSignal(SigPct));
    //CHECK GPRS
    digitalToggleFast(L_GREEN);
    //CPNNECT INTERNET
    if (!GSM.Internet()) {//0b01000000
        if (SHOW_SERIAL)
            //Serial.println(F("!g"));
       notGPRS--;

        //CHECK SIM OR HEAL GSM
        goto retry;
    }
    //sync time

    //  POST:
    //  SIZE- 850 OK
    digitalToggleFast(L_GREEN);
    if (!HTTPInit())
        goto retry;

    HTTPsetup();

    //calculate byte length of data
    //LEN_DELE = DEV=<2*2-Bytes>&DT=<2*4-Bytes>&d=<data-(dlen*2)>
    //Total len of frame = (2*dlen) + (LEN_DELE)
    // corrected json
    //     {
    // "dateTime": "2020-09-19T11:14:00.45+05:30",
    // "ph": 7,
    // "tds": 500,
    // "flowRate": 150,
    // "poweStatus": "Available",
    // "deliveryStatus":[
    // {
    // "block": "block_name",
    // "pressure": 10
    //  }
    // ]
    // }

    // st = F("{\n");
    // st += F("\"dateTime\":\"2020-09-19T11:14:00.45+05:30\",\n");
    // st += F("\"ph\": 7.0,\n");
    // st += F("\"tds\": 500,\n");
    // st += F("\"flowRate\": 150,\n");
    // st += F("\"poweStatus\": \"Available\",\n");
    // st += F("\"deliveryStatus\":[\n");
    // st += F("{\n");
    // st += F("\"block\": \"block_name\",\n");
    // st += F("\"pressure\": 10\n");
    // st += F("}\n");
    // st += F("]\n");
    // st += F("}\n");

    st = F("{\n");
    st += F("\"dateTime\":\"");
    // GET DATE AND TIME FROM MODULE
    // 2020-09-19T11:14:00.45+05:30
    // UnixToIso//but not +05:30
    UNIX = GSM.GetUnix();
    //CONVERT INTO ISO without add +5:30
    st += GetISO(UNIX);//test+ //left+
    st += F("\",\n");

  if(event_type == 1){
    st += F("\"FlowINavg\": ");
    st += (String)flow1avg_upload;
    st += F(",\n");

    st += F("\"TDSavg\": ");
    st += (String)TDSavg;
    st += F(",\n");

    st += F("\"TankIn\": ");
    st += (String)LitreIn;
    st += F(",\n");

    st += F("\"RUNminute\": ");
    st += (String)_t_;
    st += F(",\n");
  }
  else{
    st += F("\"FlowOutavg\": ");
    st += (String)flow2avg;
    st += F(",\n");

    st += F("\"TDSavg\": ");
    st += (String)TDSavg;
    st += F(",\n");

    st += F("\"TankOut\": ");
    st += (String)LitreOut;
    st += F(",\n");
  }
    // st += F("\"poweStatus\": \"Available\",\n");
    st += F("\"deliveryStatus\":[\n");
    st += F("{\n");
    st += F("\"block\": \"event1\",\n");
    st += F("\"pressure\": 10\n");
    st += F("}\n");
    st += F("]\n");
    st += F("}\n");

    //Serial.println(st);
    //    check for:-
    //    DOWNLOAD
    //  //Serial.println(F("HTTPDATA"));
    digitalToggleFast(L_GREEN);
    if (!Req_UPLOAD(LengthOf(&st))) { //DOWNLOAD
        goto retry;
    }

    //1997-07-16T19:20:30.45+01:00
    // BODY:-
    // {
    // "dateTime":"ISO Date Time format",
    // "ph": 7.0,
    // "tds": 500,
    // "flowRate": 100, //  ltr/min
    // "poweStatus": "Available", // opt - Available, Down, ....
    // "deliveryStatus":[
    // {
    //     "block": "block_name",
    //     "pressure": 12, // psi
    //     }
    // ]
    // }

    DGSM.Print(&st);

    // // {\n"dateTime":"
    //  DGSM.Print(F("{\n\"dateTime\":\""));
    //   // UNIX TIME 00000000
    //  DGSM.Print(h2s(String(0, HEX), 32));//unix time//4B
    //   // ",
    //  DGSM.Print(F("\",\n"));

    // //  "ph" :7.0,
    // DGSM.Print(F("\"ph\":"));
    //   // UNIX TIME 00000000
    //  DGSM.Print(h2s(String(0, HEX), 32));//unix time//4B
    //   // ",
    //  DGSM.Print(F("\","));

    // //ID=
    // DGSM.Print(F("ID="));
    // DGSM.Print(h2s(String(Read16Int(CLIENT_ID), HEX), 16));//2B
    // DGSM.Print(h2s(String(Read16Int(DEVICE_ID), HEX), 16));//2B
    // // DGSM.Print(h2s(String(1, HEX), 16));//2B
    // // DGSM.Print(h2s(String(1, HEX), 16));//2B

    // //&DT=
    // DGSM.Print(F("&DT="));
    // DGSM.Print(h2s(String(0, HEX), 32));//unix time//4B

    // //&G=
    // DGSM.Print(F("&D="));

    // //  AT+HTTPDATA=LEN,TIME
    // //  >>DOWNLOAD>>DATA
    // //  AT+HTTPDATA=335,1000
    // //convert ICT into IEEE754 HEX
    // DGSM.Print(h2s(String(0, HEX), 32));//ICT, 32
    // DGSM.Print(h2s(String(o.P1, HEX), 32));//P1, 32//PUT WHICH IS ACTUALLY WRITTEN
    // DGSM.Print(h2s(String(o.P2, HEX), 32));//P2, 32
    // //convert TDS vAI voltage
    // DGSM.Print(h2s(String(0, HEX), 16));//ICT, 32
    // //Directly send pressure
    // DGSM.Print(h2s(String(0, HEX), 16));//ICT, 32


    //    check for:-
    //    OK
    digitalToggleFast(L_GREEN);
    if (!GSM.CheckCmd(F(""), ZF3E0, tout1)) {
        goto retry;
    }

    //  AT+HTTPACTION=1
    //  //Serial.println(F("ACT=1"));
    digitalToggleFast(L_GREEN);
    if (!GSM.CheckCmd(F("AT+HTTPACTION=1"), ZF3E0, tout1)) {//POST
        goto retry;
    }
    //  AT+HTTPSTATUS?
    //  //Serial.println(F("STATUS"));
    //  //Serial.println(GSM.GetCmd(F("AT+HTTPSTATUS?"), ZF3E0, tout1));

    //check STATUS
    digitalToggleFast(L_GREEN);
    if (!HTTPstatus()) {
        goto retry;
    }

    //////////// VERY SENSITIVE PART /////////////
    /*
        Accepted:- 200, 202,
        Rejected:-
        ERROR:-
    */

    digitalToggleFast(L_GREEN);
    if (!Reply(ACK_LEN_LIMIT)) {
        goto retry;
    }

    //read data if Reply() is ok
    // if(!Uploded()){
    //     goto retry;
    // }
    //ACCOTDING TO STATUS READ HTTP MSG

    // ok:
    if (SHOW_SERIAL)
        ram();
    return 1;

  retry:
    //  fail(UPLOAD);
    if (Retry > 0) {
      //CHECK BIT.11 THEN RETRY -= 2
      //    if (!((Response >> 11) & 0x01))//0x800
      // if (!(Response & 0x0800)) { //0x800
      //   Retry -= 2;
      //   // fail(UPLOAD);
      // }
      // else
      Retry--;
      //Serial.println(Retry);
      // //Serial.print(F("0x"));
      // //Serial.println(Response, HEX);
      // Response = 0;//reset response
      if(notGPRS <= 0){
        // RESET MODEM
        if(GSM.Restart(RST) != 0){//every 100ms//MEMORY FRAGMENTING
                GSM.Set();
          }
        // HEAL MODEM
        notGPRS = NOT_INTERNET_COUNT;
        //Serial.println(F("EXTREME INTERNET ERROR"));
      }

      goto beg;
    }

    // fail:
    //RESTART REQUEST
    return 0;
}

void Eeeprom_UPDATE(){
  String st;
    // Optional_qDEV
    // WriteeepString(S_Optional_qDEV, E_Optional_qDEV, F("PrismL1"));
        // MC: // MODBUS COMMUNICATION
    // //get
    // EEPROM.update(MOD_FUN, GetuInt8(data, 2)); //MOD_FUNCTION
    // //get
    // EEPROM.update(PARITY, GetuInt8(data, 3)); //MOD_PARITY
    // //get
    // EEPROM.update(MOD_BAUD, GetuInt8(data, 4));//MOD_BAUD

    // MP: //MODBUS PARAMETER
    //  //######################## Slave id-1   //Fixed
    // EEPROM.update(SLAVE1, GetuInt8(data, &from, 1)); //SID-1
    // Write16Int(MOD_ADD1, GetuInt(data, &from, 2)); //ADD-1
    // EEPROM.update(nPOLL1, GetuInt8(data, &from, 3)); //REG-1
    // //CAUSE 164 BYTE OF FLASH
    // //Slave id-2
    // c[0] = GetuInt8(data, &from, 4);
    // EEPROM.update(SLAVE2, (uint8_t)c[0]); //SID-2
    // if ((uint8_t)c[0] != 0) {
    //   Write16Int(MOD_ADD2, GetuInt(data, &from, 5)); //ADD-2
    //   EEPROM.update(nPOLL2, GetuInt8(data, &from, 6)); //REG-2
    // }
    // //SO ON

    // CR: //WiFi Connect Router
    // save:
    // //SAVE TO EEPROM-
    // WriteeepString(S_SSID, E_SSID, &ssid);  //WRITE SSID
    // WriteeepString(S_PASS, E_PASS, &password);  //WRITE KEY

    // SA: set access point
    // http://bhanu.free.beeceptor.com/G_POST
    // WriteeepString(S_HOST, E_HOST, F("http://demo5089036.mockable.io")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/G_SSLTEST")); //Method
    //  https://epaqtbbwt7.execute-api.ap-south-1.amazonaws.com/dev
    // WriteeepString(S_HOST, E_HOST, F("https://epaqtbbwt7.execute-api.ap-south-1.amazonaws.com")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/dev")); //Method

    //  https://wsms.co.in
    //  /api/v1/[IMEI_NUMBER]/telemetry
    //  AT+GSN -> GET IMEI(FAIL)  867273021268029
    WriteeepString(S_HOST, E_HOST, F("https://wsms.co.in")); //Host
    // st = F("/api/v1/");https://wsms.co.in/api/v1/867273021268029/telemetry
    WriteeepString(S_METHOD, E_METHOD, F("/api/v1/867273021268029/telemetry")); //Method

    // http://86.96.203.99:81/api/parsermbus
    // WriteeepString(S_HOST, E_HOST, F("http://86.96.203.99:81")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/api/parsermbus")); //Method

    // WriteeepString(S_HOST, E_HOST, F("http://bhanu.free.beeceptor.com")); //Host
    // WriteeepString(S_METHOD, E_METHOD, F("/G_POST")); //Method

    // application/x-www-form-urlencoded
    // WriteeepString(S_CONTENT, E_CONTENT, F("application/x-www-form-urlencoded")); //Content Type

    //text/json
    WriteeepString(S_CONTENT, E_CONTENT, F("text/json"));

    // SI: //SET ID
    //SAVE TO EEPROM
    // Write16Int(CLIENT_ID, 10);
    // Write16Int(DEVICE_ID, 1);

    // DU: //data upload time and retry
    EEPROM.update(UPLOAD_d, (20 / 5)); //UPLOAD
    //upload retry
    EEPROM.update(U_RETRY, 5);

    // DR: //DATA RETRY
    // EEPROM.update(MOD_RETRY, 3); //mod_retry

    //SSL: ON or OFF

    // DT: // DEVICE TEST

}

void Eeeprom_SHOW(){
  // Serial.println(ReadeepString(S_Optional_qDEV));
/*//460 BYTE PROM
    //EEPROM TEST
    Serial.println(EEPROM.read(SLAVE1));
    Serial.println(EEPROM.read(SLAVE2));
    Serial.println(EEPROM.read(SLAVE3));
    Serial.println(EEPROM.read(SLAVE4));
    Serial.println(get_mod_baud() * 100);
    Serial.println(get_mod_parity());
    Serial.println(get_mod_fun());
    Serial.println(get_mod_retry());
    //4*Slave, Add, nPoll
  */
  //Upload Duration
  // Serial.println(get_upload() * 5);
  // Serial.println(get_client_id());
  // Serial.println(get_device_id());
//   Serial.println(get_port());

  //  / / String
//   Serial.println(ReadeepStringUpto(S_SSID, '\0'));
//   Serial.println(ReadeepStringUpto(S_PASS, '\0'));
  Serial.println(ReadeepString(S_HOST));
//   Serial.println(ReadeepStringUpto(S_HOST, ':'));
  Serial.println(ReadeepString(S_METHOD));
  Serial.println(ReadeepString(S_CONTENT));

}


void setup() {

  //WATCH DOG SETUP
    IWatchdog.reload();//RESET WATCHDOG
    IWatchdog.clearReset();
    IWatchdog.begin(WDTus);
  //pin biasing
  pinMode(IN5, INPUT_PULLDOWN);//p1
  pinMode(IN6, INPUT_PULLDOWN);//p2
  // ct analog input
  pinMode(CT_out, INPUT_PULLDOWN);
  //LED
  //left+

  wdt_reset();
  // ALL SERIAL
  // SERIAL TEST
  // Serial1.setRx(PB7); // using pin name PY_n
  // Serial1.setTx(PB6); // using pin number PYn
  //Serial.begin(115200);
  Serial.begin(gsmbaud);//GSM
  _SERIAL.begin(9600);//SERIAL

  //UPDATE Eeeprom
  Eeeprom_UPDATE();
     //For Pulse2
    // data_read();
    //GSM SETTING
    GSM.Set(ONE_TIME_BASIC);
    GSM_Heal();
    wdt_reset();
    // connect gprs in advance
  // put your setup code here, to run once:

  updateDATA->setOverflow(updateDATA_FREQ, HERTZ_FORMAT); // 20 Hz // 50ms
  updateDATA->attachInterrupt(updateDATA_IT_callback);
  updateDATA->resume();

  MotorI->setOverflow(MotorI_FREQ, HERTZ_FORMAT); // 1 Hz // 50ms
  MotorI->attachInterrupt(MotorI_IT_callback);
  MotorI->resume();

  EVENT1->setOverflow(EVENT1_FREQ, HERTZ_FORMAT); // 1 Hz // 50ms
  EVENT1->attachInterrupt(Event1_IT_callback);
  EVENT1->resume();

  //event 2 for auto save

  //attach pulse2 count interrupt
}

void loop() {
  // put your main code here, to run repeatedly:
  wdt_reset();
  //check for timer to disable
  //upload event 1
  if(is_upload_e1){
    if(UPLOAD_ENC_DATA_JSON(1)){
      is_upload_e1 = false;
    }
  }
  // event-2 periodic upload
}